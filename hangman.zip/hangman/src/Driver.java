import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Driver
{

    static ArrayList<Game> listOfGames = new ArrayList<>();
    static ArrayList<Game> sortedListOfGames = new ArrayList<>();


    public static void main(String[] args) throws IOException
    {
        menu();
    }


    public static void menu() throws IOException
    {

        Scanner in = new Scanner(System.in);

        char response = ' ';

        System.out.println
        (
            "Welcome to Aron's java Hangman!\n"
        );

        while (response != 'q')
        {

            System.out.println
            (
                """
                Select one of the following:
                   's' to start new game
                   'l' to show leaderboard
                   'q' to quit
                """
            );

            response = in.nextLine().charAt(0);

            switch (response)
            {

                case 's' -> newGame();
                case 'l' -> showLeaderBoard();
                case 'q' -> System.out.println
                        (
                                "Thanks for playing :)"
                        );
                default -> System.out.println
                        (
                                "PLEASE TYPE A VALID RESPONSE"
                        );

            }

        }

    }


    public static void newGame() throws IOException
    {

        Game aGame = new Game();
        aGame.displayAllGuessesAndNumGuessesLeft();

        while (aGame.getNumberOfGuessesLeft() > 0 &&
        aGame.numberOfUnderlinesInCorrectGuesses() > 0)
        {

            char userCharGuess = aGame.userCharGuess();
            aGame.compareChars(userCharGuess);
            aGame.displayAllGuessesAndNumGuessesLeft();

        }

        aGame.determineGameResultAndEnterUserName();

        listOfGames.add(aGame);

    }


    public static void sortGamesFromLeastToMostGuesses()
    {

        ArrayList<Game> copyOfListOfGames = new ArrayList<>(listOfGames);

        for (int i = 0; i < listOfGames.size(); i++)
        {

            Game gameLeastGuesses = copyOfListOfGames.get(0);

            for (Game currentGame : copyOfListOfGames) {
                if (currentGame.getTotalNumberOfGuesses() < gameLeastGuesses.getTotalNumberOfGuesses())
                {
                    gameLeastGuesses = currentGame;
                }
            }

            sortedListOfGames.add(gameLeastGuesses);
            copyOfListOfGames.remove(gameLeastGuesses);

        }

    }


    public static void organizeSortedListByGamesLost()
    {

        ArrayList<Game> sortedListOfGamesCopy = new ArrayList<>(sortedListOfGames);
        ArrayList<Game> lostGames = new ArrayList<>();

        for (Game currentGame : sortedListOfGamesCopy) {

            if (currentGame.getNumberOfGuessesLeft() == 0) {

                lostGames.add(currentGame);
                sortedListOfGames.remove(currentGame);

            }

        }

        sortedListOfGames.addAll(lostGames);

    }
    // then maybe you can make lostGames static, and organize lostGames in order of least to most underlines left


    private static void showLeaderBoard()
    {

        System.out.println
        (
            "---------------------------------- Leaderboard ----------------------------------"
        );

        sortGamesFromLeastToMostGuesses();
        organizeSortedListByGamesLost();

        for (int i = 0; i < sortedListOfGames.size(); i++)
        {
            System.out.println
            (
                "#" + (i + 1) + ": " +
                sortedListOfGames.get(i).toString() + "\n" +
                "---------------------------------------------------------------------------------"
            );
        }

        System.out.println();

    }


}
