import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Game {


    private String randomWord;
    private char[] correctGuesses;
    private int numberOfGuessesLeft;
    private int totalNumberOfGuesses;
    private ArrayList<Character> incorrectGuessedLetters = new ArrayList<Character>();
    private String userName;


    public Game() throws IOException {


        Random rand = new Random();
        File aFile = new File("wordList");
        Scanner inFile = new Scanner(aFile);

        String randWord = "";

        for (int i = 0; i < rand.nextInt(855); i++) {
            randWord = inFile.next();
        }

        randomWord = randWord;


        correctGuesses = new char[randWord.length()];

        for (int i = 0; i < correctGuesses.length; i++) {
            correctGuesses[i] = '_';
        }


        int randWordLength = randomWord.length();

        if (randWordLength <= 3) {
            numberOfGuessesLeft = 5;
        }
        else if (randWordLength <= 5) {
            numberOfGuessesLeft = 6;
        }
        else if (randWordLength <= 7) {
            numberOfGuessesLeft = 7;
        }
        else {
            numberOfGuessesLeft = 9;
        }


    }


    public char userCharGuess() {

        Scanner in = new Scanner(System.in);

        System.out.println("Enter a letter to guess: ");
        char userCharGuess = in.nextLine().charAt(0);

        totalNumberOfGuesses++;

        return userCharGuess;

    }


    public void compareChars(char userCharGuess) {

        int counter = 0;

        for (int i = 0; i < randomWord.length(); i++) {

            if (randomWord.charAt(i) == userCharGuess) {
                correctGuesses[i] = userCharGuess;
            }
            else {
                counter++;
            }

        }

        if (counter == randomWord.length()) {

            if (!checkIfAlreadyInIncorrectGuesses(userCharGuess)) {
                numberOfGuessesLeft--;
                incorrectGuessedLetters.add(userCharGuess);
                System.out.println(
                        "'" + userCharGuess + "' was not a letter in the word."
                );
            }

        }
        else if (counter > 0) {
            System.out.println(
                    "'" + userCharGuess + "' is a letter in the word!"
            );
        }

    }


    public void displayAllGuessesAndNumGuessesLeft() {

        System.out.println(
                "Correct guesses:\n"
        );

        for (int i = 0; i < correctGuesses.length; i++) {
            System.out.print(
                    correctGuesses[i] + " "
            );
        }

        System.out.print(
                "\n\nIncorrect guesses: "
        );

        for (int j = 0; j < incorrectGuessedLetters.size(); j++) {

            if (j < incorrectGuessedLetters.size() - 1) {
                System.out.print(
                        incorrectGuessedLetters.get(j) + ", "
                );
            }
            else {
                System.out.print(
                        incorrectGuessedLetters.get(j)
                );
            }

        }

        System.out.println(
                "\nNumber of guesses left: " + numberOfGuessesLeft
        );

    }


    public int numberOfUnderlinesInCorrectGuesses() {

        int numberOfUnderlinesInCorrectGuesses = 0;

        for (int i = 0; i < correctGuesses.length; i++) {

            if (correctGuesses[i] == '_') {
                numberOfUnderlinesInCorrectGuesses++;
            }

        }

        return numberOfUnderlinesInCorrectGuesses;

    }


    public void determineGameResultAndEnterUserName() {

        Scanner in = new Scanner(System.in);

        if (numberOfUnderlinesInCorrectGuesses() == 0) {
            System.out.println(
                "\nYou Guessed the word!\n" +
                "You won :)\n" +
                "The answer was: " + randomWord + "\n"
            );
        }

        else if (numberOfGuessesLeft == 0) {
            System.out.println(
                "\nYou're out of guesses\n" +
                "you lost :(\n" +
                "The answer was: " + randomWord + "\n"
            );
        }

        System.out.print(
            "Enter your name: "
        );
        userName = in.nextLine();
        System.out.println("\n");

    }


    public boolean checkIfAlreadyInIncorrectGuesses(char userCharGuess) {

        boolean isAlreadyInIncorrectGuesses = false;

        for (int i = 0; i < incorrectGuessedLetters.size(); i++) {

            if (incorrectGuessedLetters.get(i) == userCharGuess) {
                isAlreadyInIncorrectGuesses = true;
                totalNumberOfGuesses--;
            }

        }

        if (isAlreadyInIncorrectGuesses) {
            System.out.println(
                "You already guessed this letter!"
            );
        }

        return isAlreadyInIncorrectGuesses;

    }


    public String getRandomWord() {
        return randomWord;
    }

    public void setRandomWord(String randomWord) {
        this.randomWord = randomWord;
    }

    public int getNumberOfGuessesLeft() {
        return numberOfGuessesLeft;
    }

    public void setNumberOfGuessesLeft(int numberOfGuessesLeft) {
        this.numberOfGuessesLeft = numberOfGuessesLeft;
    }

    public int getTotalNumberOfGuesses() {
        return totalNumberOfGuesses;
    }

    public void setTotalNumberOfGuesses(int totalNumberOfGuesses) {
        this.totalNumberOfGuesses = totalNumberOfGuesses;
    }

    public char[] getCorrectGuesses() {
        return correctGuesses;
    }

    public void setCorrectGuesses(char[] correctGuesses) {
        this.correctGuesses = correctGuesses;
    }

    @Override
    public String toString() {

        return  userName + "\n\n" +
                "The word: " + randomWord + "\n" +
                "Total number of guesses: " + totalNumberOfGuesses + "\n" +
                "Number of guesses left: " + numberOfGuessesLeft;

    }


}